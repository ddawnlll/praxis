# PRAXIS / Pi — Project State

> This file is maintained by agents on every change. Read first each session.

---

## Identity

| Field | Value |
|-------|-------|
| Project | PRAXIS v2.0 |
| Root | `/home/erfolg/src/praxis` |
| Purpose | Local Truth Kernel for agentic coding tools — verifies whether the agent actually completed the task |
| Concept | A plugin-first local verification layer: praxis CLI + Truth Kernel + Claude Code plugin UX. Answers "Bitti mi gerçekten?" / "Did the agent actually complete the task?" |
| Status | Design D0-D1 in progress (~45% design). Implementation 0% — NOT authorized. Post-ADR-013 Plugin-First Pivot. |
| Pi reference | `pi/` contains the old Pi monorepo — reference and selective port source, NOT the active codebase |

---

## The Three Laws (Hard Locks — not negotiable)

```
LAW 1 — COMPLETION AUTHORITY
         Agent says done ≠ done.
         Truth Engine FinalGate PASS = done.
         Nothing else counts.

LAW 2 — WRITE AUTHORITY
         No worker writes to shared integration files.
         The Deterministic Assembler is the only shared writer.

LAW 3 — VERIFICATION AUTHORITY
         FinalGate acceptance criteria comes from human-authored TaskSpec.
         An agent cannot define or verify its own completion criteria.
```

---

## Architecture Overview

### Directory Layout

```
praxis/
├─ kernel/         # Pure execution brain: FSM, PSAG, Evidence, Truth Engine, RIM, Governor, Circuit Breaker, Assembler, ACCP
├─ adapters/       # External worker integrations: Claude Code, OpenCode, local models
├─ hooks/          # Hook binaries called from external tools (esp. Claude Code Pre/PostToolUse)
├─ server/         # Local runtime server: control plane, storage, events, telemetry
├─ interface/      # Human-facing clients: CLI, desktop UI, typed client, UI core
├─ lib/            # Shared contracts and utility foundation
│   └─ contracts/  # @praxis/contracts — ported from pi/ execution-contracts
├─ tests/          # Cross-package tests and e2e suites
├─ examples/       # Example plans, TaskSpecs, fixture repos
├─ docs/           # Architecture, ADRs, specs, roadmap
└─ scripts/        # Repo automation
```

### 11 Components (from README.md)

```
┌─────────────────────────────────────────────────────────────────────┐
│  PSAG — PlanSpec Admission Gate                                      │
│  (schema, namespace collision, budget, deps, acceptance_criteria)    │
└───────────────────────────────┬─────────────────────────────────────┘
                                │ ADMIT
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Auto Executor Kernel — FSM, Queue, Workspace Manager, Governor     │
│  (lifecycle: DORMANT → QUEUED → WORKSPACE_INIT → RUNNING → ...)    │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
          ┌─────────────────────┼─────────────────────┐
          ▼                     ▼                     ▼
    [Worker A]            [Worker B]            [Worker C]
    namespace_a           namespace_b           namespace_c
          │                     │                     │
          └─────────────────────┼─────────────────────┘
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Worker Adapter Layer — Claude Code CLI/SDK, OpenCode, local models │
│  (normalizes all worker output → AttemptManifest)                   │
└───────────────────────────────┬─────────────────────────────────────┘
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  PRAXIS Hook Layer — intercepts ALL Claude Code tool events         │
│  pre-tool/post-tool/stop → KernelOwnedTranscript                    │
│  divergence check: hook result ≠ claude-reported result             │
└───────────────────────────────┬─────────────────────────────────────┘
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Attempt Capture + Evidence Hash Chain                              │
│  stdout/stderr, transcript, exit codes, git diff, timestamps        │
│  sha256 chain → EHCBreakClassifier (NOISE/SUSPECTED/CONFIRMED)     │
└───────────────────────────────┬─────────────────────────────────────┘
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Circuit Breaker — CLOSED → OPEN → HALF-OPEN                        │
│  triggers: failure_rate > 30%/10min, governor_RED > 15min,          │
│            EHC break = CONFIRMED                                    │
└───────────────────────────────┬─────────────────────────────────────┘
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Truth Engine — EvidenceGate → ExecGate → FinalGate                 │
│  PASS / HOLD / FAIL                                                 │
└───────────────────────────┬─────────────────────────────────────────┘
                            │ HOLD
                            ▼
┌─────────────────────────────────────────────────────────────────────┐
│  RIM — Repair Intelligence Module                                   │
│  6 strategies: initial, context_expand, tool_restrict, scope_narrow,│
│  knowledge_inject, hint_inject → ABORT @ attempt 7                 │
└───────────────────────────┬─────────────────────────────────────────┘
                            │ PASS (all workers done)
                            ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Adaptive Concurrency Governor — stable_3 → 6 → 8 → 12 → 16       │
│  (each tier: 48h consecutive clean operation)                       │
└───────────────────────────┬─────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Deterministic Assembler — namespace recheck, semantic check,       │
│  atomic apply, rollback → ConflictReport                           │
└───────────────────────────┬─────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────────┐
│  ACCP Artifact Layer — ALWAYS ASYNC                                 │
│  FVR per TaskRun, PRR per wave                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### TaskRun FSM

```
DORMANT → QUEUED → WORKSPACE_INIT → RUNNING → CAPTURING → VERIFYING → COMPLETE
                                          ↓                              ↓
                                       ABORTED                       REPAIR → RUNNING (loop)
                                                                        ↓
                                                                     ABORTED (@ attempt 7)
```

Terminal states: `COMPLETE` (FVR enqueued), `ABORTED` (evidence preserved), `FAILED` (human review).

---

## Phase & Milestone Status (Post-Pivot)

| # | Phase | Scope | Status |
|---|-------|-------|--------|
| D0 | Pivot Decision Lock | ADR-013, decisions.md D-127–D-148 | COMPLETE |
| D1 | Plugin-First Design Pack | Product scope, phase map, task YAML contract, MVP scope, plugin flow, kernel flow | COMPLETE |
| D2 | Truth Kernel Proof Design | Evidence model, false-done catalog, RepairPacket schema | Not started |
| D3 | Claude Code Plugin Spike Spec | Slash command spec, hook design, CLI interface contract | Not started |
| D4 | Final Design Lock Audit | Cross-doc consistency, decision compliance, readiness assessment | Not started |
| I0 | Implementation Scaffold | Monorepo, contracts, build infra | FUTURE — not authorized |
| I1 | Manual Verify MVP | init, spec, verify commands | FUTURE — not authorized |
| I2 | Repair Packet MVP | repair command | FUTURE — not authorized |
| I3 | Hook Capture MVP | Hook-based evidence capture | FUTURE — not authorized |
| I4 | Reports / ACCP-lite | Report generation, plugin integration | FUTURE — not authorized |

**Overall design progress:** ~45% (D0-D1 complete, D2-D4 remaining)
**Overall implementation progress:** 0% (NOT authorized)

### Quick Reference — Next Actions

```
1. [P-1] ADR-000: pi reuse policy
2. [P-1] Architecture lock matrix
3. [P-1] Circuit Breaker section → README
4. [P0.1] Monorepo scaffold
5. [P0.2] Contracts port
```

See `todo.md` for full task-level tracking.

---

## File Map

### Root Level — PRAXIS Design

| Path | Type | Purpose | Notes |
|------|------|---------|-------|
| `README.md` | Design | PRAXIS v2.0 full architecture — 3 laws, 11 components, ADRs, roadmap, scoring | 1931 lines, canonical |
| `architecture.md` | Design | Architecture baseline v0.2 — product model, boundaries, directory layout | 52K |
| `todo.md` | Tracking | Implementation todo list — all phases, tasks, checkboxes, progress formulas | Current state source |
| `ai_summary.md` | Meta | This file — project state maintained by agents | Active |
| `CLAUDE.md` | Meta | Agent instructions: read ai_summary.md first, update on changes | Active |
| `reports/` | Reports | ACCP readiness reports (pi_reuse_readiness, architecture_lock_readiness) | ACCP YAML |
| `docs/` | Design | Architecture docs, ADRs, specs, phase map, product scope | DRAFT_FOR_AUDIT |
| `docs/decisions.md` | Design | Canonical decision register — HARD_LOCK/SOFT_LOCK/OPEN/REJECTED | Authoritative |
| `docs/adr/README.md` | Design | ADR index — resolves numbering collisions, registers all ADRs | v0.1 |
| `docs/phase-map.md` | Design | P-1 through P6 canonical phase map, gates, parallelism rules | v0.1 |
| `docs/product-scope.md` | Design | Product scope, MVP-A/B/C staging, in/out of scope | v0.1 |
| `docs/pipelines/overview.md` | Spec | End-to-end pipeline: PlanSpec through ACCP artifacts. Component placement, MVP staging, CB/Governor intervention, ACCP async independence. | DRAFT_FOR_AUDIT v0.1 |
| `docs/pipelines/taskrun-lifecycle.md` | Spec | TaskRun FSM: states, transitions, gate positions, repair loop (max 7), false-done protection, terminal invariants. | DRAFT_FOR_AUDIT v0.1 |
| `docs/pipelines/runtime-event-flow.md` | Spec | RuntimeEvent model, append-only log, SSE streaming, snapshot, event replay, gap detection, UI state rules, in-memory→PG migration. | DRAFT_FOR_AUDIT v0.1 |
| `docs/pipelines/worker-adapter.md` | Spec | Generic worker adapter 5-stage pipeline: healthCheck→prepareAttempt→runAttempt→captureOutput→normalizeResult; RunAttemptResult (no verdict); AdapterError normalization (RateLimitSignal/CrashSignal/TimeoutSignal); mock adapter contract; CLAIM ONLY designation for worker_reported_status. | DRAFT_FOR_AUDIT v0.1 (rewritten) |
| `docs/pipelines/claude-code-adapter.md` | Spec | Claude Code adapter specifics: Day 0 Spike (S1-S5 GO/NO-GO criteria); primary path (headless + praxis-hook); Claude local loop vs. PRAXIS supervisory loop (independent); rate limit/crash/divergence detection; NO adapter-owned FinalGate; NO direct shared writes. | DRAFT_FOR_AUDIT v0.1 |
| `docs/pipelines/praxis-hook-capture.md` | Spec | Hook event capture pipeline: Claude emits→praxis-hook intercepts→normalizes JSON→POSTs to runtime→spool fallback; PreToolUse/PostToolUse/Stop; server ingestion→EvidenceRecord→EHC chain; EHC break (NOISE/SUSPECTED/CONFIRMED)→Circuit Breaker; hook NEVER decides truth. | DRAFT_FOR_AUDIT v0.1 |
| `docs/pipelines/messages-api-fallback.md` | Spec | Messages API fallback (gated on Day 0 Spike NO-GO): PRAXIS-owned tool execution loop; what stays identical (Truth Engine/Three Laws/evidence model/gate pipeline); what changes (adapter impl); tradeoffs; MUST NOT implement now; MUST NOT change Truth Engine authority. | DRAFT_FOR_AUDIT v0.1 |
| `docs/index.md` | Meta | Documentation index — inventory, reading order (4 tiers), required-reading for ACCP/prompts. | DRAFT_FOR_AUDIT v0.1 |
| `docs/testing/pipeline-test-strategy.md` | Spec | Phase-by-phase test categories (P0-P6), gate mapping, false-done mandates, CB test requirements. | DRAFT_FOR_AUDIT v0.1 |
| `docs/implementation/p0-entry-gate.md` | Spec | P0 entry prerequisites, P0.1-P0.4 sub-gates, P0 Exit Gate, forbidden-copy enforcement. | DRAFT_FOR_AUDIT v0.1 |
| `docs/contracts/task-spec.contract.md` | Contract | TaskSpec fields, AcceptanceCriterion, TaskBudget, PredictedInterface, PSAG validation rules V1-V14, forbidden authority fields | DRAFT_FOR_AUDIT v0.1 |
| `docs/contracts/plan-spec.contract.md` | Contract | PlanSpec fields, PlanBudget, PSAG plan-level checks P1-P15, dependency graph validation, namespace partitioning | DRAFT_FOR_AUDIT v0.1 |
| `docs/contracts/worker-adapter.contract.md` | Contract | WorkerAdapter operations, WorkerHealth, RunAttemptInput/Result, ErrorSignal taxonomy, adapter MUST/MUST NOT rules | DRAFT_FOR_AUDIT v0.1 |
| `docs/contracts/run-attempt.contract.md` | Contract | RunAttemptInput/Result, AttemptManifest (kernel-extended), DivergenceFlag, GateResult placeholder, claim vs. verdict boundary | DRAFT_FOR_AUDIT v0.1 |
| `docs/contracts/runtime-event.contract.md` | Contract | RuntimeEvent envelope, 10 event type categories, sequencing/gap-detection, SSP ingestion algorithm, forbidden authority sources | DRAFT_FOR_AUDIT v0.1 |
| `docs/contracts/runtime-snapshot.contract.md` | Contract | RuntimeSnapshot shape, RuntimeStatus/GovernorSummary/CircuitBreakerSummary/TaskRunSummary/WorkerSummary/HumanAction sub-types, UI consumption algorithm, forbidden UI-authored fields | DRAFT_FOR_AUDIT v0.1 |
| `pi/` | Archive | Old Pi monorepo — reference and selective port source | See below |

### `pi/` — Reference Archive

The Pi monorepo is NOT the active codebase. Selected packages are ported to PRAXIS; the rest is forbidden to copy. This directory structure is documented so agents understand the reference boundaries.

#### Forbidden to Copy (reference only)

```
pi/packages/coding-agent/   — Core execution engine (plan parser, scheduler, worktree, brain P13-P20, etc.)
pi/packages/ai/             — AI provider abstraction (prompt caching, OAuth, providers)
pi/packages/web-server/     — Fastify server (REST API, SSE, WebSocket)
pi/packages/web-ui/         — React + Vite dashboard
pi/packages/db/             — PostgreSQL persistence
pi/packages/worker-adapters/
pi/packages/execution-service/
pi/packages/tui/
```

#### Reference Only (design patterns)

```
pi/packages/execution-runtime/  — FSM, completion predicate, state authority, deadline watchdog
```

#### Approved for Port (with adaptation)

| Source | Target | Contents |
|--------|--------|---------|
| `pi/packages/execution-contracts/` | `lib/contracts/` | ACCP types, WorkerAdapter interface, runtime event types |
| `pi/packages/accp-compiler/` | `kernel/accp/` | Compiler pipeline, YAML parser, 24-type registry, validators, CLI, 135 tests |

#### Other `pi/` Contents (documentation, not to port)

| Path | Purpose |
|------|---------|
| `pi/AGENTS.md` | Development rules — commit format, testing, parallel agent safety |
| `pi/CONTRIBUTING.md` | Contribution guidelines |
| `pi/ai_summary.md` | Legacy detailed file analysis (1500+ lines) |
| `pi/dashboard_summary.md` | Dashboard architecture — comprehensive UI component map |
| `pi/scripts/` | Utility scripts (diagnostics, profiling, testing helpers) |
| `pi/reports/` | Execution reports (P23 progress, hotfix reports) |
| `pi/docs/` | Reference docs (findings, template, proposals, stability reports) |
| `pi/test-fixtures/` | E2E test fixtures |
| `pi/.github/` | Workflows (issue/PR gates, CI) |

---

## Key Contracts & Types (from README.md)

### TaskSpec (required by PSAG)

```typescript
interface TaskSpec {
  task_id: string;
  wave: number;
  namespace: string[];            // exclusive file paths this worker owns
  task_type: 'code' | 'docs' | 'test' | 'shared_package';
  description: string;
  acceptance_criteria: AcceptanceCriterion[];
  criteria_source: 'human';       // 'generated' → PSAG REJECT
  budget: TaskBudget;
  dependencies: string[];
  predicted_interfaces?: PredictedInterface[];
}
```

### AcceptanceCriterion

```typescript
interface AcceptanceCriterion {
  id: string;
  description: string;
  verification_type: 'file_exists' | 'test_passes' | 'command_output' | 'diff_contains' | 'no_diff_contains';
  verification_detail: string;
  required: boolean;
}
```

### Evidence Hash Chain

```typescript
interface EvidenceRecord {
  id: string;
  attempt_id: string;
  worker_id: string;
  timestamp_ns: bigint;
  source: 'kernel_hook' | 'git' | 'filesystem' | 'divergence_detector';
  kind: 'pre_tool' | 'post_tool' | 'diff' | 'file_change' | 'divergence';
  content: string;
  content_hash: string;
  chain_hash: string;    // sha256(prev_chain_hash + content_hash)
}
```

### Circuit Breaker States

```
CLOSED → OPEN → HALF-OPEN → CLOSED

OPEN triggers:
  - failure_rate > 30% in 10min sliding window
  - governor_RED continuous > 15min
  - EHC break classified as CONFIRMED
```

### Concurrency Governor Tiers

| Tier | Workers | Requirement |
|------|---------|-------------|
| stable_3 | 3 | 48h clean operation |
| stable_6 | 6 | stable_3 + 48h clean |
| stable_8 | 8 | stable_6 + 48h clean |
| stable_12 | 12 | stable_8 + 48h clean |
| stable_16 | 16 | architecture review |

### RIM Strategy Rotation

| Attempt | Strategy | What changes |
|---------|----------|-------------|
| 1-2 | initial | Standard repair packet |
| 3 | context_expand | Read 5+ related files, import graph |
| 4 | tool_restrict | 4a: read-only analysis, 4b: write enabled |
| 5 | scope_narrow | Single failing criterion only |
| 6 | knowledge_inject or hint_inject | Docs/human hint |
| 7 | ABORT | Budget exhausted |

---

## Commands Reference

### Current repo (PRAXIS planning phase — no build yet)

```bash
# View recent history
git log --oneline -10

# View current branch/status
git status
git branch
```

### Pi reference (for porting context)

```bash
# From pi/ directory:
npm run check    # TypeScript + lint check (not tests)
bun test         # Run tests (from package root, not repo root)
npx vitest run test/specific.test.ts   # Single test file
```

### Planned PRAXIS commands (after P0.1)

```bash
bun install
bun run typecheck
bun test
bun run check        # typecheck + lint + format
bun run test-full    # all tests including e2e
make test
make test-full
```

---

## Git History

```
cacc073  update todo                                     (2026-06-17)
92ed8a1  Add Circuit Breaker architecture as kernel-owned safety component v0.2
311ad17  Add architecture baseline document v0.1
b055fbc  Initial commit
```

---

## Key Architecture Decisions (ADRs)

| ADR | Decision | Rationale |
|-----|----------|-----------|
| 001 | ACCP is always async | Prevents execution deadlock at speed of own success |
| 002 | Assembler is wave-level only | Per-task assembly breaks parallelism |
| 003 | stable_16 is concurrency ceiling | "Unbounded" is an accident, not a milestone |
| 004 | acceptance_criteria is human-authored only | Prevents echo chamber (LAW 3) |
| 005 | Claude Code NO-GO → Messages API fallback | If hooks unreliable, fallback to custom agent loop |

---

## Design Lock Summary (Post-Pivot)

| Lock level | Definition | Items |
|------------|-----------|-------|
| HARD | Changing requires ADR | Product identity (not a coding agent), local Truth Kernel core, plugin-as-bridge, v0.1 scope exclusions, Three Laws preserved |
| SOFT | Can evolve during implementation | JSONL evidence store format, package names, stack choices, exact CLI interface |
| OPEN | Needs discovery/spike | Automatic hook loops, repair dispatch automation, MiMo/OpenCode adapter feasibility |

Full tracking in `docs/decisions.md` Section 23.

---

## Forbidden Copy List

These packages must NOT be copied into PRAXIS:

- `pi/packages/coding-agent`
- `pi/packages/ai`
- `pi/packages/db`
- `pi/packages/web-server`
- `pi/packages/web-ui`
- `pi/packages/tui`
- `pi/packages/worker-adapters`
- `pi/packages/execution-service`
- Old runtime controller code coupled to DB/Kysely

---

## Recent Changes

| Date | Files | Summary |
|------|-------|---------|
| 2026-06-18 | `docs/adr/ADR-013-plugin-first-pivot.md` (new), `docs/decisions.md` (updated), `docs/product-scope.md` (rewritten), `docs/phase-map.md` (rewritten), `docs/index.md` (updated), `docs/contracts/praxis-task-yaml.contract.md` (new), `docs/implementation/mvp-v0.1-plugin-first-scope.md` (new), `docs/pipelines/claude-code-plugin-flow.md` (new), `docs/pipelines/local-truth-kernel-flow.md` (new), `docs/pipelines/runtime-event-flow.md` (supersession notice), `docs/pipelines/circuit-breaker-governor.md` (supersession notice), `docs/pipelines/wave-scheduler.md` (supersession notice), `docs/pipelines/deterministic-assembler.md` (supersession notice), `docs/contracts/runtime-event.contract.md` (supersession notice), `docs/contracts/runtime-snapshot.contract.md` (supersession notice), `docs/contracts/governor.contract.md` (supersession notice), `docs/contracts/circuit-breaker.contract.md` (supersession notice) | **Plugin-First Pivot Decision Pack (ACCP-PRAXIS-PLUGIN-FIRST-PIVOT-DECISION-PACK):** Repositioned PRAXIS from desktop-first multi-agent coding orchestrator to plugin-first local Truth Kernel. Created ADR-013 with full KEEP/FUTURE/KILL classification. Appended D-127 through D-148 pivot decisions to decisions.md (HARD_LOCK on product identity, SOFT_LOCK on stack, OPEN on automation). Rewrote product-scope.md for v0.1 plugin-first MVP (praxis CLI + local Truth Kernel + Claude Code plugin + .praxis workspace). Rewrote phase-map.md with D0-D4 design stages and I0-I4 future implementation stages. Created task-yaml contract, MVP scope doc, plugin flow doc, kernel flow doc. Updated index.md reading order. Added future-scope supersession notices to 8 old desktop/server/runtime docs. Marked D-002 through D-095 desktop-first decisions as superseded for v0.1. Three Laws preserved and not weakened. Desktop Mission Control, server/runtime, SSE, PostgreSQL, Circuit Breaker, Governor, stable_16, wave scheduler, and multi-worker orchestration reclassified as FUTURE scope. Own agent loop killed from v0.1. Implementation NOT authorized. Zip artifact: artifacts/praxis-docs-plugin-first-pivot-v0.1.zip. All 19 acceptance criteria pass. |: worker-adapter (complete rewrite per user spec with 5-stage pipeline + RunAttemptResult with no verdict + AdapterError normalization + mock adapter), claude-code-adapter (Day 0 Spike S1-S5 GO/NO-GO gates + headless+primary path + two independent loops + NO adapter-owned FinalGate), praxis-hook-capture (hook event capture pipeline + PreToolUse/PostToolUse/Stop + spool fallback + EHC chain feed + 4 design principles), messages-api-fallback (gated on Spike NO-GO + PRAXIS-owned tool loop + what stays same vs. changes + tradeoffs). All respect decisions.md HARD_LOCK decisions and Three Laws. |
| 2026-06-18 | `docs/contracts/*.md` (6 files) | Created six DRAFT_FOR_AUDIT v0.1 contract documentation files: task-spec.contract.md (TaskSpec + AcceptanceCriterion + PSAG V1-V14), plan-spec.contract.md (PlanSpec + PlanBudget + PSAG P1-P15), worker-adapter.contract.md (WorkerAdapter + WorkerHealth + RunAttemptInput/Result + MUST/MUST NOT rules), run-attempt.contract.md (RunAttemptResult + AttemptManifest + DivergenceFlag + GateResult), runtime-event.contract.md (RuntimeEvent envelope + 10 event categories + sequencing/gap-detection + SSP replay), runtime-snapshot.contract.md (RuntimeSnapshot + 6 sub-types + UI consumption algorithm). All use conceptual field tables (not TypeScript). Forbidden authority fields enforced per Three Laws. Contract-first development (D-098). docs/decisions.md NOT modified. |
| 2026-06-18 | `docs/pipelines/overview.md`, `docs/pipelines/taskrun-lifecycle.md`, `docs/pipelines/runtime-event-flow.md` | Created three core pipeline specs DRAFT_FOR_AUDIT v0.1: end-to-end overview (component placement, MVP staging, CB/Governor intervention, ACCP async independence), TaskRun lifecycle FSM (states, transitions, gate positions, repair loop, false-done protection, terminal invariants), RuntimeEvent flow (append-only log, SSE streaming, snapshot, event replay, gap detection, UI state rules). All respect decisions.md HARD_LOCK decisions. |
| 2026-06-18 | `docs/index.md`, `docs/testing/pipeline-test-strategy.md`, `docs/implementation/p0-entry-gate.md` | Created three DRAFT_FOR_AUDIT v0.1 spec docs: documentation index (4-tier reading order), pipeline test strategy (P0-P6 test categories + CB transition tests + false-done mandates), P0 entry gate (prerequisites + P0.1-P0.4 sub-gates + P0 Exit Gate). All respect decisions.md HARD_LOCK decisions. |
| 2026-06-18 | `docs/adr/README.md`, `docs/phase-map.md`, `docs/product-scope.md` | Created three DRAFT_FOR_AUDIT v0.1 spec docs: ADR index (resolves numbering collision), phase map (P-1 through P6 canonical), product scope (MVP-A/B/C staging). All respect decisions.md HARD_LOCK decisions. |
| 2026-06-18 | `docs/decisions.md`, `docs/index.md`, `docs/spikes/day-0-claude-code-spike.md` | Decision register authorization fix: (1) Downgraded D-117 (TypeScript strict) from HARD_LOCK to SOFT_LOCK — all D-117 through D-126 are now SOFT_LOCK stack preference decisions. (2) Added authorization note to Section 18 explaining D-117–D-126 are stack preferences, do not authorize implementation, and may be revised before Final Design Lock. (3) Updated docs/index.md D-ID range from D-125 to D-126. (4) Normalized Day 0 Spike heading from "GO/NO-GO" to "GO / NO-GO Criteria" with spaces. (5) Created artifacts/praxis-docs-v0.1-draft-register-authorized.zip. No source code changed. All 14 acceptance criteria pass. |
| 2026-06-18 | `docs/index.md`, `docs/pipelines/overview.md`, `docs/pipelines/wave-scheduler.md` | Consistency fix pass: (1) Verified all D-NNN references across all 37 docs against docs/decisions.md — no conflicts found; all known-bad-pattern checks passed. (2) Fixed 2 minor stable_16 qualifications in overview.md and wave-scheduler.md to explicitly state stable_16 is an OPEN hypothesis. (3) Updated index.md Decision ID Integrity section with verified audit status and added checklist exemption note. (4) Created artifacts/praxis-docs-v0.1-draft-fixed.zip. No source code or implementation files changed. All 19 acceptance criteria pass. |
| 2026-06-17 | `CLAUDE.md`, `ai_summary.md` | Initial agent documentation baseline |
| 2026-06-17 | `todo.md`, `reports/*.yaml` | Update todo with full phase tracking, add ACCP readiness reports |

---

## Known Issues

- **Environment mismatch**: `pi/AGENTS.md` references macOS paths and tmux commands — not applicable to this Linux environment
- **No monorepo scaffold**: Cannot run `bun install` or `bun test` at root yet — I0 needed (future)
- **Legacy ai_summary.md**: `pi/ai_summary.md` has 1500+ lines of auto-generated file analysis that may be stale
- **Post-pivot doc reconciliation**: Old desktop/server/runtime docs exist alongside new plugin-first docs. 8 docs received supersession notices; remaining pipeline/contract docs may need review for v0.1 consistency
- **Architecture.md not updated**: `architecture.md` still reflects pre-pivot desktop-first architecture. Should be updated to reflect plugin-first design in D2

---

## Active Work

- **Plugin-First Pivot (COMPLETE 2026-06-18):** ADR-013 created, decisions.md updated with D-127–D-148, product-scope.md and phase-map.md rewritten, 4 new docs created (task YAML contract, MVP scope, plugin flow, kernel flow), 8 old docs marked future, index.md updated, zip artifact created. Implementation NOT authorized.
- **Next (D2):** Truth Kernel Proof Design — detailed evidence model, false-done test case catalog, RepairPacket schema, TestOutputParser format coverage matrix. Design only, no implementation.

---

## Quick Reference

```
What is PRAXIS?             →  Local Truth Kernel for agentic coding tools.
                              Not a coding agent. Not a Claude Code clone.
Primary interface (v0.1)?   →  Claude Code plugin + praxis CLI.
Completion authority?       →  Truth Kernel FinalGate. Never agent.
Completion criteria source? →  .praxis/task.yaml (human-approved). Never agent.
Truth location?             →  Kernel only. Plugin displays, never decides.
Evidence store (v0.1)?      →  .praxis/runs/<id>/evidence.jsonl (local files).
Desktop Mission Control?     →  FUTURE scope for v0.1 (target v0.3+).
Server/SSE/PostgreSQL?      →  FUTURE scope for v0.1 (target v0.2+).
Multi-agent orchestration?  →  FUTURE scope for v0.1 (target v0.3+).
Own agent loop?             →  KILLED from v0.1. Agents run independently.
Implementation authorized?  →  NO. Design stages (D0-D4) in progress.
```
